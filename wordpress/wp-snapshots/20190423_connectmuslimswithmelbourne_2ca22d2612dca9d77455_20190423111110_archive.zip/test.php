<!DOCTYPE html>
<html>
<head>
 <title> Table with database</title>
</head>
<body>
<table>
  <tr>
    <th>Suburb</th>
  </tr>

<?php
$conn = mysqli_connect("localhost", "root", "fm3dfm3d", "muslim_db");
if ($conn-> connect_error) {
  die("Connection failed:" . $conn-> connect_error);
}
 
  $sql = "SELECT suburb FROM crime LIMIT 1,3";
  $result = $conn-> query($sql);

  if ($result-> num_rows > 0) {
    while ($row = $result-> fetch_assoc()) {
      echo "<tr><td>". $row["suburb"]."</td></tr>";
    }
    echo "</table>";
  }
  else {
    echo "0 result";
  }
 $conn-> close();
?>

</table>
</body>
</html>
